#!/bin/bash

#1. Script create the sudo groups and add all team members into respective groups
#2. Script Execute the chef client to reflect templates immediately
#3. Script Verify all templates created or not via cc in /etc/sudoers.d/*
#4. Script Delete old individual users sudo templates from /etc/sudoers.d/* excluding $SKIPSUDOFILES

# Written on 25thMar2018 by Rahul Kolan`
#USAGE
   #Script Filename


FILENAME=$1
#echo $FILENAME;
SKIPUSERS=['automate','sasauto']
SKIPSUDOFILES="automate|sasauto|401_SLA_OPS_SWAT_LCL|402_SLA_SAS_ASE_LCL|403_SLA_RCP_SWAT_LCL|404_SLA_ASB_LCL|405_SLA_APIE_LCL|406_SLA_SUPER_ADM_LCL"
while IFS=, read -a eachLine;do
GROUP=${eachLine[7]}
USER=${eachLine[0]}
GROUPEXIST=0
USEREXIST=0
 #echo "Group name $GROUP user $USER"
 GROUPEXIST=$(cat /etc/group | egrep -i "^$GROUP:" | wc -l)
 #echo $GROUPEXIST;

 if [ $GROUPEXIST == 0 ]; then
   echo "Group name $GROUP not exist hence creating"
   `groupadd $GROUP`
  else
  echo "Group name $GROUP already exist"
fi

  USEREXIST=$(cat /etc/passwd | egrep -i "^$USER:" | wc -l)
  #echo "USEREXIST $USEREXIST for $USER"
  if [ $USEREXIST == 0 ]; then
   echo "user name $USER not exist so skip this condition and looking for next row"
  else
  USEREXISTINGROUP=$(cat /etc/group | egrep -i "^$GROUP:" | egrep -i "[:,?]$USER(,?)" | wc -l)
  if [ $USEREXISTINGROUP == 0 ]; then
  echo "user $USER  exist hence adding into group"
   `usermod -a -G $GROUP $USER`
    #`rm -f /etc/sudoers.d/$USER`
   else
   echo "user $USER already exists in group. so skip this row."
   if echo ${SKIPUSERS[@]} | grep -q -w "$USER"; then
   echo "USER $USER FOUND IN SKIPUSER, So not removing from sudoers"
  else
echo " "
   #echo "USER $USER NOT FOUND IN SKIPUSER, So removing from sudoers"
  #`rm -f /etc/sudoers.d/$USER`
  fi
  fi
 fi

done < $FILENAME

/opt/IBM/cobalt/etc/chef/run_chef_client.sh -c /opt/IBM/cobalt/etc/chef/client.rb -o policy_linux_sudo
rm -f `ls -r /etc/sudoers.d/* | egrep -v "$SKIPSUDOFILES"`
