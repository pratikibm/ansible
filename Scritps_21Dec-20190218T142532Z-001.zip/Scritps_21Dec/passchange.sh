#!/bin/bash
echo "Enter the userid"
read userid
rm servers
for i in `cat server_list`;do echo $(grep -i $i all_server.csv | cut -d "," -f2) >>servers; done

user_name=`cat pass_file | cut -d ":" -f1`
new_passwd=`cat pass_file| cut -d ":" -f2`

for i in `cat servers`; do ssh -i id_rsa -p 2222 $userid@$i "uname -n;echo '==================================';echo $new_passwd | sudo passwd --stdin $user_name;echo '===================================='"; done
