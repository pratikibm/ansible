#echo 'Enter the IP which need to search'
#echo 'Enter the server userid'
#read KEYWORD
#read username
rm -rf output.odt
for host in `cat server`;do 

   for i in `cat pattern`;do
      
    if [[ -n "$(ssh -p 2222 -o StrictHostKeyChecking=no -o BatchMode=yes -i id_rsa pratshin@$host sudo grep -i $i /var/log/messages && echo Y)" ]]; then
        echo "$i pattern found on  $host" >> output.odt
    fi
   done
done
