#!/bin/bash
#Pratik Shinde
rm -rf servers
 if [ -n "$1" ]
  then
    echo $(grep -i $1 Devicesinfo | cut -d "," -f2) >>servers;
    for i in `cat servers`;do ssh -i ~/.ssh/id_ed25519 -p 2222 pratshin@$i;done 
 else 
     read ip
     ssh -i ~/.ssh/id_ed25519 -p 2222 pratshin@$ip
  fi

