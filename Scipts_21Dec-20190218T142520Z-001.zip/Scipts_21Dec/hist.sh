#!/bin/bash
#Script to add History parameter in /etc/profile


#HISTSIZE="export HISTSIZE"
#HISTTIME="export HISTTIMEFORMAT"
#sudo grep -w "^export HISTSIZE=20000\|^export HISTTIMEFORMAT" /etc/profile


sudo grep -w "^export HISTTIMEFORMAT" /etc/profile
if [ $? -eq 0 ]
 then  
   echo "Alredy addedd parameter"
else
  cat >>/etc/profile << EOL
#export HISTSIZE=20000
export HISTTIMEFORMAT='%F %T '
EOL

fi
